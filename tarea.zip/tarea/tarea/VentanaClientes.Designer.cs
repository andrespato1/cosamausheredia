﻿namespace tarea
{
    partial class VentanaClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtCodigoCliente = new System.Windows.Forms.TextBox();
            this.TxtCodigoPostal = new System.Windows.Forms.TextBox();
            this.TxtDireccion = new System.Windows.Forms.TextBox();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.TxtTelefono = new System.Windows.Forms.TextBox();
            this.TxtEmail = new System.Windows.Forms.TextBox();
            this.TxtFecha = new System.Windows.Forms.TextBox();
            this.TxtUbicacion = new System.Windows.Forms.TextBox();
            this.TxtEntrega = new System.Windows.Forms.TextBox();
            this.TxtCondicion = new System.Windows.Forms.TextBox();
            this.TxtBusquedaCliente = new System.Windows.Forms.TextBox();
            this.TxtCredito = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.DataGridClientes = new System.Windows.Forms.DataGridView();
            this.BtnAgregar = new System.Windows.Forms.Button();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.BtnActualizar = new System.Windows.Forms.Button();
            this.BtnBuscarCliente = new System.Windows.Forms.Button();
            this.CBBuscarCliente = new System.Windows.Forms.ComboBox();
            this.btnAtras = new System.Windows.Forms.Button();
            this.checkBusquedaCliente = new System.Windows.Forms.CheckBox();
            this.dataGridCondicionPagoEnCliente = new System.Windows.Forms.DataGridView();
            this.ayudaCliente = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCondicionPagoEnCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtCodigoCliente
            // 
            this.TxtCodigoCliente.Location = new System.Drawing.Point(142, 12);
            this.TxtCodigoCliente.Name = "TxtCodigoCliente";
            this.TxtCodigoCliente.Size = new System.Drawing.Size(100, 20);
            this.TxtCodigoCliente.TabIndex = 0;
            // 
            // TxtCodigoPostal
            // 
            this.TxtCodigoPostal.Location = new System.Drawing.Point(142, 90);
            this.TxtCodigoPostal.Name = "TxtCodigoPostal";
            this.TxtCodigoPostal.Size = new System.Drawing.Size(100, 20);
            this.TxtCodigoPostal.TabIndex = 1;
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.Location = new System.Drawing.Point(142, 64);
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.Size = new System.Drawing.Size(100, 20);
            this.TxtDireccion.TabIndex = 2;
            // 
            // TxtNombre
            // 
            this.TxtNombre.Location = new System.Drawing.Point(142, 38);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(100, 20);
            this.TxtNombre.TabIndex = 3;
            // 
            // TxtTelefono
            // 
            this.TxtTelefono.Location = new System.Drawing.Point(142, 142);
            this.TxtTelefono.Name = "TxtTelefono";
            this.TxtTelefono.Size = new System.Drawing.Size(100, 20);
            this.TxtTelefono.TabIndex = 7;
            // 
            // TxtEmail
            // 
            this.TxtEmail.Location = new System.Drawing.Point(142, 168);
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.Size = new System.Drawing.Size(100, 20);
            this.TxtEmail.TabIndex = 6;
            // 
            // TxtFecha
            // 
            this.TxtFecha.Location = new System.Drawing.Point(142, 194);
            this.TxtFecha.Name = "TxtFecha";
            this.TxtFecha.Size = new System.Drawing.Size(100, 20);
            this.TxtFecha.TabIndex = 5;
            // 
            // TxtUbicacion
            // 
            this.TxtUbicacion.Location = new System.Drawing.Point(142, 116);
            this.TxtUbicacion.Name = "TxtUbicacion";
            this.TxtUbicacion.Size = new System.Drawing.Size(100, 20);
            this.TxtUbicacion.TabIndex = 4;
            // 
            // TxtEntrega
            // 
            this.TxtEntrega.Location = new System.Drawing.Point(142, 247);
            this.TxtEntrega.Name = "TxtEntrega";
            this.TxtEntrega.Size = new System.Drawing.Size(100, 20);
            this.TxtEntrega.TabIndex = 11;
            // 
            // TxtCondicion
            // 
            this.TxtCondicion.Location = new System.Drawing.Point(142, 273);
            this.TxtCondicion.Name = "TxtCondicion";
            this.TxtCondicion.Size = new System.Drawing.Size(100, 20);
            this.TxtCondicion.TabIndex = 10;
            // 
            // TxtBusquedaCliente
            // 
            this.TxtBusquedaCliente.Location = new System.Drawing.Point(360, 43);
            this.TxtBusquedaCliente.Name = "TxtBusquedaCliente";
            this.TxtBusquedaCliente.Size = new System.Drawing.Size(190, 20);
            this.TxtBusquedaCliente.TabIndex = 9;
            // 
            // TxtCredito
            // 
            this.TxtCredito.Location = new System.Drawing.Point(142, 221);
            this.TxtCredito.Name = "TxtCredito";
            this.TxtCredito.Size = new System.Drawing.Size(100, 20);
            this.TxtCredito.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Codigo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Telefono";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Pais";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Codigo Postal";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Direccion";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Nombre";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 197);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Fecha";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Limite de credito";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 249);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Direccion de Entrega";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 276);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Condicion de pago";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // DataGridClientes
            // 
            this.DataGridClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridClientes.Location = new System.Drawing.Point(360, 70);
            this.DataGridClientes.Name = "DataGridClientes";
            this.DataGridClientes.Size = new System.Drawing.Size(456, 256);
            this.DataGridClientes.TabIndex = 23;
            // 
            // BtnAgregar
            // 
            this.BtnAgregar.Location = new System.Drawing.Point(270, 10);
            this.BtnAgregar.Name = "BtnAgregar";
            this.BtnAgregar.Size = new System.Drawing.Size(75, 23);
            this.BtnAgregar.TabIndex = 24;
            this.BtnAgregar.Text = "Agregar";
            this.BtnAgregar.UseVisualStyleBackColor = true;
            this.BtnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Location = new System.Drawing.Point(270, 36);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(75, 23);
            this.BtnEliminar.TabIndex = 25;
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Location = new System.Drawing.Point(270, 61);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(75, 23);
            this.BtnActualizar.TabIndex = 26;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // BtnBuscarCliente
            // 
            this.BtnBuscarCliente.Location = new System.Drawing.Point(741, 43);
            this.BtnBuscarCliente.Name = "BtnBuscarCliente";
            this.BtnBuscarCliente.Size = new System.Drawing.Size(75, 23);
            this.BtnBuscarCliente.TabIndex = 27;
            this.BtnBuscarCliente.Text = "Buscar";
            this.BtnBuscarCliente.UseVisualStyleBackColor = true;
            this.BtnBuscarCliente.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // CBBuscarCliente
            // 
            this.CBBuscarCliente.FormattingEnabled = true;
            this.CBBuscarCliente.Location = new System.Drawing.Point(556, 43);
            this.CBBuscarCliente.Name = "CBBuscarCliente";
            this.CBBuscarCliente.Size = new System.Drawing.Size(172, 21);
            this.CBBuscarCliente.TabIndex = 28;
            // 
            // btnAtras
            // 
            this.btnAtras.Location = new System.Drawing.Point(9, 393);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(75, 23);
            this.btnAtras.TabIndex = 29;
            this.btnAtras.Text = "Atras";
            this.btnAtras.UseVisualStyleBackColor = true;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // checkBusquedaCliente
            // 
            this.checkBusquedaCliente.AutoSize = true;
            this.checkBusquedaCliente.Location = new System.Drawing.Point(360, 14);
            this.checkBusquedaCliente.Name = "checkBusquedaCliente";
            this.checkBusquedaCliente.Size = new System.Drawing.Size(272, 17);
            this.checkBusquedaCliente.TabIndex = 30;
            this.checkBusquedaCliente.Text = "Desea visualizar todas las columnas en la busqueda";
            this.checkBusquedaCliente.UseVisualStyleBackColor = true;
            // 
            // dataGridCondicionPagoEnCliente
            // 
            this.dataGridCondicionPagoEnCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCondicionPagoEnCliente.Location = new System.Drawing.Point(125, 310);
            this.dataGridCondicionPagoEnCliente.Name = "dataGridCondicionPagoEnCliente";
            this.dataGridCondicionPagoEnCliente.Size = new System.Drawing.Size(138, 65);
            this.dataGridCondicionPagoEnCliente.TabIndex = 31;
            // 
            // ayudaCliente
            // 
            this.ayudaCliente.Location = new System.Drawing.Point(692, 380);
            this.ayudaCliente.Name = "ayudaCliente";
            this.ayudaCliente.Size = new System.Drawing.Size(75, 23);
            this.ayudaCliente.TabIndex = 32;
            this.ayudaCliente.Text = "AYUDA";
            this.ayudaCliente.UseVisualStyleBackColor = true;
            // 
            // VentanaClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 428);
            this.Controls.Add(this.ayudaCliente);
            this.Controls.Add(this.dataGridCondicionPagoEnCliente);
            this.Controls.Add(this.checkBusquedaCliente);
            this.Controls.Add(this.btnAtras);
            this.Controls.Add(this.CBBuscarCliente);
            this.Controls.Add(this.BtnBuscarCliente);
            this.Controls.Add(this.BtnActualizar);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.BtnAgregar);
            this.Controls.Add(this.DataGridClientes);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtEntrega);
            this.Controls.Add(this.TxtCondicion);
            this.Controls.Add(this.TxtBusquedaCliente);
            this.Controls.Add(this.TxtCredito);
            this.Controls.Add(this.TxtTelefono);
            this.Controls.Add(this.TxtEmail);
            this.Controls.Add(this.TxtFecha);
            this.Controls.Add(this.TxtUbicacion);
            this.Controls.Add(this.TxtNombre);
            this.Controls.Add(this.TxtDireccion);
            this.Controls.Add(this.TxtCodigoPostal);
            this.Controls.Add(this.TxtCodigoCliente);
            this.Name = "VentanaClientes";
            this.Text = "VentanaClientes";
            this.Load += new System.EventHandler(this.VentanaClientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCondicionPagoEnCliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtCodigoCliente;
        private System.Windows.Forms.TextBox TxtCodigoPostal;
        private System.Windows.Forms.TextBox TxtDireccion;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.TextBox TxtTelefono;
        private System.Windows.Forms.TextBox TxtEmail;
        private System.Windows.Forms.TextBox TxtFecha;
        private System.Windows.Forms.TextBox TxtUbicacion;
        private System.Windows.Forms.TextBox TxtEntrega;
        private System.Windows.Forms.TextBox TxtCondicion;
        private System.Windows.Forms.TextBox TxtBusquedaCliente;
        private System.Windows.Forms.TextBox TxtCredito;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView DataGridClientes;
        private System.Windows.Forms.Button BtnAgregar;
        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.Button BtnActualizar;
        private System.Windows.Forms.Button BtnBuscarCliente;
        private System.Windows.Forms.ComboBox CBBuscarCliente;
        private System.Windows.Forms.Button btnAtras;
        private System.Windows.Forms.CheckBox checkBusquedaCliente;
        private System.Windows.Forms.DataGridView dataGridCondicionPagoEnCliente;
        private System.Windows.Forms.Button ayudaCliente;
    }
}
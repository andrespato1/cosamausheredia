﻿namespace tarea
{
    partial class VentanaPersonal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtIDPersonal = new System.Windows.Forms.TextBox();
            this.TxtApellido2 = new System.Windows.Forms.TextBox();
            this.TxtApellido1 = new System.Windows.Forms.TextBox();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.TxtPuesto = new System.Windows.Forms.TextBox();
            this.TxtTelefono = new System.Windows.Forms.TextBox();
            this.TxtNacimiento = new System.Windows.Forms.TextBox();
            this.TxtEmail = new System.Windows.Forms.TextBox();
            this.TxtIDJefe = new System.Windows.Forms.TextBox();
            this.TxtFechaIngreso = new System.Windows.Forms.TextBox();
            this.TxtFechaRetiro = new System.Windows.Forms.TextBox();
            this.TxtResidencia = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.BtnAgregar = new System.Windows.Forms.Button();
            this.BtnBuscarPersonal = new System.Windows.Forms.Button();
            this.BtnActualizar = new System.Windows.Forms.Button();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.DataGridPersonal = new System.Windows.Forms.DataGridView();
            this.CBBuscarPersonal = new System.Windows.Forms.ComboBox();
            this.TxtBuscarPersonal = new System.Windows.Forms.TextBox();
            this.botonAtras = new System.Windows.Forms.Button();
            this.checkBusquedaPersonal = new System.Windows.Forms.CheckBox();
            this.ayudaPersonal = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPersonal)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtIDPersonal
            // 
            this.TxtIDPersonal.Location = new System.Drawing.Point(132, 12);
            this.TxtIDPersonal.Name = "TxtIDPersonal";
            this.TxtIDPersonal.Size = new System.Drawing.Size(100, 20);
            this.TxtIDPersonal.TabIndex = 0;
            // 
            // TxtApellido2
            // 
            this.TxtApellido2.Location = new System.Drawing.Point(132, 116);
            this.TxtApellido2.Name = "TxtApellido2";
            this.TxtApellido2.Size = new System.Drawing.Size(100, 20);
            this.TxtApellido2.TabIndex = 1;
            // 
            // TxtApellido1
            // 
            this.TxtApellido1.Location = new System.Drawing.Point(132, 90);
            this.TxtApellido1.Name = "TxtApellido1";
            this.TxtApellido1.Size = new System.Drawing.Size(100, 20);
            this.TxtApellido1.TabIndex = 2;
            // 
            // TxtNombre
            // 
            this.TxtNombre.Location = new System.Drawing.Point(132, 64);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(100, 20);
            this.TxtNombre.TabIndex = 3;
            // 
            // TxtPuesto
            // 
            this.TxtPuesto.Location = new System.Drawing.Point(132, 38);
            this.TxtPuesto.Name = "TxtPuesto";
            this.TxtPuesto.Size = new System.Drawing.Size(100, 20);
            this.TxtPuesto.TabIndex = 4;
            // 
            // TxtTelefono
            // 
            this.TxtTelefono.Location = new System.Drawing.Point(132, 168);
            this.TxtTelefono.Name = "TxtTelefono";
            this.TxtTelefono.Size = new System.Drawing.Size(100, 20);
            this.TxtTelefono.TabIndex = 5;
            // 
            // TxtNacimiento
            // 
            this.TxtNacimiento.Location = new System.Drawing.Point(132, 142);
            this.TxtNacimiento.Name = "TxtNacimiento";
            this.TxtNacimiento.Size = new System.Drawing.Size(100, 20);
            this.TxtNacimiento.TabIndex = 6;
            // 
            // TxtEmail
            // 
            this.TxtEmail.Location = new System.Drawing.Point(132, 220);
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.Size = new System.Drawing.Size(100, 20);
            this.TxtEmail.TabIndex = 11;
            // 
            // TxtIDJefe
            // 
            this.TxtIDJefe.Location = new System.Drawing.Point(132, 246);
            this.TxtIDJefe.Name = "TxtIDJefe";
            this.TxtIDJefe.Size = new System.Drawing.Size(100, 20);
            this.TxtIDJefe.TabIndex = 10;
            // 
            // TxtFechaIngreso
            // 
            this.TxtFechaIngreso.Location = new System.Drawing.Point(132, 272);
            this.TxtFechaIngreso.Name = "TxtFechaIngreso";
            this.TxtFechaIngreso.Size = new System.Drawing.Size(100, 20);
            this.TxtFechaIngreso.TabIndex = 9;
            // 
            // TxtFechaRetiro
            // 
            this.TxtFechaRetiro.Location = new System.Drawing.Point(132, 298);
            this.TxtFechaRetiro.Name = "TxtFechaRetiro";
            this.TxtFechaRetiro.Size = new System.Drawing.Size(100, 20);
            this.TxtFechaRetiro.TabIndex = 8;
            // 
            // TxtResidencia
            // 
            this.TxtResidencia.Location = new System.Drawing.Point(132, 194);
            this.TxtResidencia.Name = "TxtResidencia";
            this.TxtResidencia.Size = new System.Drawing.Size(100, 20);
            this.TxtResidencia.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Puesto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Nombre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Primer Apellido";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Segundo Apellido";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Fecha Nacimiento";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Fecha Retiro";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 275);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Fecha Ingreso";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 249);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "ID Jefe";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Email";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 197);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Residencia";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 171);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "Telefono";
            // 
            // BtnAgregar
            // 
            this.BtnAgregar.Location = new System.Drawing.Point(262, 22);
            this.BtnAgregar.Name = "BtnAgregar";
            this.BtnAgregar.Size = new System.Drawing.Size(75, 23);
            this.BtnAgregar.TabIndex = 24;
            this.BtnAgregar.Text = "Agregar";
            this.BtnAgregar.UseVisualStyleBackColor = true;
            this.BtnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // BtnBuscarPersonal
            // 
            this.BtnBuscarPersonal.Location = new System.Drawing.Point(799, 57);
            this.BtnBuscarPersonal.Name = "BtnBuscarPersonal";
            this.BtnBuscarPersonal.Size = new System.Drawing.Size(75, 23);
            this.BtnBuscarPersonal.TabIndex = 25;
            this.BtnBuscarPersonal.Text = "Buscar";
            this.BtnBuscarPersonal.UseVisualStyleBackColor = true;
            this.BtnBuscarPersonal.Click += new System.EventHandler(this.BtnBuscarPersonal_Click);
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Location = new System.Drawing.Point(262, 80);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(75, 23);
            this.BtnActualizar.TabIndex = 26;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.Location = new System.Drawing.Point(262, 51);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(75, 23);
            this.BtnEliminar.TabIndex = 27;
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // DataGridPersonal
            // 
            this.DataGridPersonal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridPersonal.Location = new System.Drawing.Point(381, 93);
            this.DataGridPersonal.Name = "DataGridPersonal";
            this.DataGridPersonal.Size = new System.Drawing.Size(493, 280);
            this.DataGridPersonal.TabIndex = 28;
            // 
            // CBBuscarPersonal
            // 
            this.CBBuscarPersonal.FormattingEnabled = true;
            this.CBBuscarPersonal.Location = new System.Drawing.Point(624, 59);
            this.CBBuscarPersonal.Name = "CBBuscarPersonal";
            this.CBBuscarPersonal.Size = new System.Drawing.Size(169, 21);
            this.CBBuscarPersonal.TabIndex = 29;
            // 
            // TxtBuscarPersonal
            // 
            this.TxtBuscarPersonal.Location = new System.Drawing.Point(381, 59);
            this.TxtBuscarPersonal.Name = "TxtBuscarPersonal";
            this.TxtBuscarPersonal.Size = new System.Drawing.Size(237, 20);
            this.TxtBuscarPersonal.TabIndex = 30;
            // 
            // botonAtras
            // 
            this.botonAtras.Location = new System.Drawing.Point(13, 340);
            this.botonAtras.Name = "botonAtras";
            this.botonAtras.Size = new System.Drawing.Size(75, 23);
            this.botonAtras.TabIndex = 31;
            this.botonAtras.Text = "Atras";
            this.botonAtras.UseVisualStyleBackColor = true;
            this.botonAtras.Click += new System.EventHandler(this.botonAtras_Click);
            // 
            // checkBusquedaPersonal
            // 
            this.checkBusquedaPersonal.AutoSize = true;
            this.checkBusquedaPersonal.Location = new System.Drawing.Point(381, 27);
            this.checkBusquedaPersonal.Name = "checkBusquedaPersonal";
            this.checkBusquedaPersonal.Size = new System.Drawing.Size(244, 17);
            this.checkBusquedaPersonal.TabIndex = 32;
            this.checkBusquedaPersonal.Text = "Desea ver todas las columnas de la busqueda";
            this.checkBusquedaPersonal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBusquedaPersonal.UseVisualStyleBackColor = true;
            // 
            // ayudaPersonal
            // 
            this.ayudaPersonal.Location = new System.Drawing.Point(262, 109);
            this.ayudaPersonal.Name = "ayudaPersonal";
            this.ayudaPersonal.Size = new System.Drawing.Size(75, 23);
            this.ayudaPersonal.TabIndex = 33;
            this.ayudaPersonal.Text = "AYUDA";
            this.ayudaPersonal.UseVisualStyleBackColor = true;
            // 
            // VentanaPersonal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 387);
            this.Controls.Add(this.ayudaPersonal);
            this.Controls.Add(this.checkBusquedaPersonal);
            this.Controls.Add(this.botonAtras);
            this.Controls.Add(this.TxtBuscarPersonal);
            this.Controls.Add(this.CBBuscarPersonal);
            this.Controls.Add(this.DataGridPersonal);
            this.Controls.Add(this.BtnEliminar);
            this.Controls.Add(this.BtnActualizar);
            this.Controls.Add(this.BtnBuscarPersonal);
            this.Controls.Add(this.BtnAgregar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtEmail);
            this.Controls.Add(this.TxtIDJefe);
            this.Controls.Add(this.TxtFechaIngreso);
            this.Controls.Add(this.TxtFechaRetiro);
            this.Controls.Add(this.TxtResidencia);
            this.Controls.Add(this.TxtNacimiento);
            this.Controls.Add(this.TxtTelefono);
            this.Controls.Add(this.TxtPuesto);
            this.Controls.Add(this.TxtNombre);
            this.Controls.Add(this.TxtApellido1);
            this.Controls.Add(this.TxtApellido2);
            this.Controls.Add(this.TxtIDPersonal);
            this.Name = "VentanaPersonal";
            this.Text = "VentanaPersonal";
            this.Load += new System.EventHandler(this.VentanaPersonal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPersonal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtIDPersonal;
        private System.Windows.Forms.TextBox TxtApellido2;
        private System.Windows.Forms.TextBox TxtApellido1;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.TextBox TxtPuesto;
        private System.Windows.Forms.TextBox TxtTelefono;
        private System.Windows.Forms.TextBox TxtNacimiento;
        private System.Windows.Forms.TextBox TxtEmail;
        private System.Windows.Forms.TextBox TxtIDJefe;
        private System.Windows.Forms.TextBox TxtFechaIngreso;
        private System.Windows.Forms.TextBox TxtFechaRetiro;
        private System.Windows.Forms.TextBox TxtResidencia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button BtnAgregar;
        private System.Windows.Forms.Button BtnBuscarPersonal;
        private System.Windows.Forms.Button BtnActualizar;
        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.DataGridView DataGridPersonal;
        private System.Windows.Forms.ComboBox CBBuscarPersonal;
        private System.Windows.Forms.TextBox TxtBuscarPersonal;
        private System.Windows.Forms.Button botonAtras;
        private System.Windows.Forms.CheckBox checkBusquedaPersonal;
        private System.Windows.Forms.Button ayudaPersonal;
    }
}